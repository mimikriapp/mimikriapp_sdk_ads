package com.mimikriapp.ads.sdk.util;

public interface OnShowAdCompleteListener {
    void onShowAdComplete();
}